<?php 
    // return array('mysql:host=localhost;dbname=coordina_coordinator', 'root', '');
    // return array('mysql:host=localhost:3306;dbname=coordina_coordinator', 'coordina_codeit', 'codeit1234!');
    return array('mysql:host=localhost;dbname=coordina_coordinator', 'coordina_codeit', 'codeit1234!');
?>