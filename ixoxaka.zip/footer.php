
    <!-- page footer -->
    <footer id="footer">
        <div class="grid-row clear">
            <div class="footer">
                <div id="copyright">Copyright<span> COORDINATOR MARKETING & SERVICES</span> <?php echo date("Y"); ?>-All Rights Reserved
                </div>
                <a href="index.html" class="footer-logo">
					<img src="images/slider/9ef32698-8604-46dd-83fc-fe5241fc4b04.jpg" alt="" style="height: 50px;">
				</a>
                <!-- <div class="social">
                                <a href="#"><div class="contact-round"><i class="fa fa-twitter"></i></div></a>
                                <a href="#"><div class="contact-round"><i class="fa fa-facebook"></i></div></a>
                                <a href="#"><div class="contact-round"><i class="fa fa-skype"></i></div></a>
                                <a href="#"><div class="contact-round"><i class="fa fa-rss"></i></div></a>
                                <a href="#"><div class="contact-round"><i class="fa fa-linkedin"></i></div></a>
                            </div> -->
            </div>
        </div>
    </footer>
    <!--/ page footer -->
    <a href="#" id="scroll-top" class="scroll-top"><i class="fa fa-angle-up"></i></a>
    <!-- scripts -->
    <script src="js/jquery.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.video.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.layeranimation.min.js">
    </script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
    <script type="text/javascript" src="rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript"
        src="http://google-maps-utility-library-v3.googlecode.com/svn/trunk/infobox/src/infobox_packed.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/jquery.owl.carousel.js"></script>
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/jquery.fancybox-media.js"></script>
    <script src="js/retina.min.js"></script>
    <!--/ scripts -->
</body>

</html>