<?php
class aboutusBAL
{
    public $id=0;
    public $title="";
    public $content="";
    public $image="";
}
?>
