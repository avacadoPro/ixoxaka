<?php
class clients1BAL
{
    public $id=0;
    public $image="";
}
?>
