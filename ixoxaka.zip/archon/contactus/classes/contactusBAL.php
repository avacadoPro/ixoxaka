<?php
class contactusBAL
{
    public $id=0;
    public $address="";
    public $phoneNo="";
    public $email="";
    public $workTime="";
}
?>
