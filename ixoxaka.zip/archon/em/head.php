<!DOCTYPE html>
<html>
<head>
	<title>Emails</title>
	<script async defer src="https://buttons.github.io/buttons.js"></script>

<!-- Bootstrap -->
<link href="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" rel="stylesheet">
<!-- dataTables -->
<link href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
<link rel="shortcut icon" href="../images/logo.png">

</head>
<body>
<style>
body {
	padding: 20px 10px 20px 10px
}
</style>