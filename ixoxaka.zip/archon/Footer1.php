<!-- footer content -->
<footer>
	<div class="pull-right" style="padding-right: 2%">
		<!-- <a href="https://colorlib.com">Colorlib</a> -->
		All Copyrights Reserved by <b>Coordinator</b>
	</div>
	<div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>
<div id="custom_notifications" class="custom-notifications dsp_none">
<ul class="list-unstyled notifications clearfix" data-tabbed_notifications="notif-group">
</ul>
<div class="clearfix"></div>
<div id="notif-group" class="tabbed_notifications"></div>
</div>
<!-- jQuery -->
<script src="../../js/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../js/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../js/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<!-- <script src="../js/nprogress/nprogress.js"></script> -->
<!-- Custom Theme Scripts -->
<script src="../js/custom.min.js"></script>
<!-- bootstrap progress js -->
<script src="../js/progressbar/bootstrap-progressbar.min.js"></script>
<script src="../js/nicescroll/jquery.nicescroll.min.js"></script>
<!-- icheck -->
<script src="../js/icheck/icheck.min.js"></script>
<!-- pace -->
<script src="../js/pace/pace.min.js"></script>


 <!-- jQuery -->
    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="../vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="../vendors/nprogress/nprogress.js"></script>
    
    <!-- Custom Theme Scripts -->
    <script src="../build/js/custom.min.js"></script>



</body>
</html>