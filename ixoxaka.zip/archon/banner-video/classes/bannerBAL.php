<?php
class bannerBAL
{
    public $id=0;
    public $videoURL="";
}
?>
