<?php
class funfactsBAL
{
    public $id=0;
    public $creativeWork=0;
    public $satisfiedClients=0;
    public $cupsofcoffee=0;
}
?>
