<?php 
        return array('mysql:host=localhost;dbname=coordina_coordinator', 'root', '');n?>
