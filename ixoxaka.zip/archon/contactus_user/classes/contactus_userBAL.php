<?php
class contactus_userBAL
{
    public $id=0;
    public $userName="";
    public $email="";
    public $website="";
    public $message="";
}
?>
