<?php
class blogBAL
{
    public $id=0;
    public $title="";
    public $content="";
    public $shortcontent="";
    public $image="";
    public $tags="";
    public $arthor="";
    public $dateofcreation=null;
}
?>
